from django.db import models
import uuid

# Create your models here.

class TelegramUser(models.Model):
    telegram_id = models.BigIntegerField(unique=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255, blank=True, null=True)
    username = models.CharField(max_length=255, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    workplace = models.CharField(max_length=255, blank=True, null=True)
    position = models.CharField(max_length=255, blank=True, null=True)
    data_processing_agreement = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    auth_token = models.CharField(max_length=64, blank=True, null=True, unique=True)
    is_expert = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.first_name} {self.last_name} (@{self.username})"

    def generate_auth_token(self):
        self.auth_token = uuid.uuid4().hex
        self.save()
        return self.auth_token

    def has_completed_test(self):
        return hasattr(self, 'testresult')
    
    def has_completed_quiz(self):
        return hasattr(self, 'quizresult')


class TestResult(models.Model):
    ANALYST_TYPES = [
        ('EP', 'Аналитик-решала'),
        ('EJ', 'Аналитик-суетолог'),
        ('IP', 'Аналитик-вайбик'),
        ('IJ', 'Аналитик-стратег'),
    ]
    
    user = models.OneToOneField(TelegramUser, on_delete=models.CASCADE, related_name='testresult')
    analyst_type = models.CharField(max_length=2, choices=ANALYST_TYPES)
    analyst_name = models.CharField(max_length=255)
    animal = models.CharField(max_length=255)
    description = models.TextField()
    tags = models.JSONField(default=list)
    ei_score = models.IntegerField()
    pj_score = models.IntegerField()
    gift_received = models.BooleanField(default=False)
    completed_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.user.first_name} - {self.analyst_name}"


class QuizResult(models.Model):
    user = models.OneToOneField(TelegramUser, on_delete=models.CASCADE, related_name='quizresult')
    correct_answers = models.IntegerField()
    total_questions = models.IntegerField()
    answers = models.JSONField(default=list)  # Список ответов пользователя
    completed_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.user.first_name} - {self.correct_answers}/{self.total_questions}"


class Workshop(models.Model):
    title = models.CharField(max_length=255)
    tag = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.start_time} - {self.end_time})"


class WorkshopRegistration(models.Model):
    user = models.ForeignKey(TelegramUser, on_delete=models.CASCADE, related_name='workshop_registrations')
    workshop = models.ForeignKey(Workshop, on_delete=models.CASCADE, related_name='registrations')
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'workshop')

    def __str__(self):
        return f"{self.user} -> {self.workshop}"


class ConsultationTopic(models.Model):
    name = models.CharField(max_length=255, unique=True)
    experts = models.ManyToManyField('TelegramUser', related_name='expert_topics', blank=True, limit_choices_to={'is_expert': True})

    def __str__(self):
        return self.name


class ConsultationSlot(models.Model):
    expert = models.ForeignKey(TelegramUser, on_delete=models.CASCADE, related_name='consultation_slots')
    topic = models.ForeignKey(ConsultationTopic, on_delete=models.CASCADE, related_name='slots')
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    is_booked = models.BooleanField(default=False)
    booked_by = models.ForeignKey(TelegramUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='consultations')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['start_time']
        unique_together = ('expert', 'start_time', 'end_time')

    def __str__(self):
        return f"{self.topic.name} with {self.expert.first_name} at {self.start_time}"
